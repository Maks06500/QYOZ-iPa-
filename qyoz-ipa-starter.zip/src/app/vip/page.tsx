import Link from "next/link";
import { supabaseServer } from "@/lib/supabase-server";
export default async function Vip() {
 const sb=await supabaseServer(); const {data:{user}}=await sb.auth.getUser();
 return <main className="section"><div className="eyebrow">QYOZ IPA MEMBERSHIP</div><h1>Unlock the VIP experience.</h1><p className="muted">Un abonnement pour soutenir le projet et accéder aux contenus additionnels que tu es autorisé à proposer.</p>
 <div className="panel" style={{maxWidth:560,marginTop:28}}><span className="tag">VIP MEMBERSHIP</span><div className="price" style={{marginTop:16}}>2,99 € <span style={{fontSize:15,color:"#aaa6bb",fontWeight:500}}> / mois</span></div><ul className="muted" style={{lineHeight:2}}><li>Accès aux fiches et contenus réservés VIP</li><li>Navigation sans publicité (si publicités ajoutées)</li><li>Nouveautés VIP en avant-première</li><li>Gestion de l'abonnement depuis ton compte</li></ul>
 {user?<form action="/api/checkout" method="POST"><button className="btn primary" type="submit">S'abonner avec Stripe</button></form>:<Link className="btn primary" href="/login">Créer un compte pour devenir VIP</Link>}
 <p className="muted" style={{fontSize:12}}>Renouvellement mensuel. Annulation selon les conditions affichées au paiement. Paiement sécurisé par Stripe.</p></div></main>;
}