import Link from "next/link";
import { supabaseServer } from "@/lib/supabase-server";
export default async function Home() {
 const supabase = await supabaseServer();
 const {data:apps} = await supabase.from("apps").select("id,title,description,category,version,is_vip").eq("published",true).order("created_at",{ascending:false}).limit(30);
 return <main>
  <section className="hero"><div className="eyebrow">THE iOS APP LIBRARY</div><h1>Discover your next<br/><span style={{color:"#a78bfa"}}>iOS experience.</span></h1><p>Un catalogue clair pour découvrir des applications et jeux iOS.<br/>Des fiches détaillées, des nouveautés et un espace membre.</p><div className="actions"><Link className="btn primary" href="#catalogue">Explorer le catalogue</Link><Link className="btn" href="/vip">Découvrir VIP · 2,99 €/mois</Link></div></section>
  <section className="section" id="catalogue"><h2>Dernières applications</h2><p className="muted">Les applications affichées doivent être distribuées avec l'autorisation de leurs ayants droit.</p>
  <div className="grid">{apps?.length ? apps.map((app:any)=><article className="card" key={app.id}><div className="appicon">✦</div><div className="tag">{app.is_vip?"VIP":"GRATUIT"} · {app.category}</div><h3>{app.title}</h3><p className="muted">{app.description}</p><small className="muted">Version {app.version || "—"}</small><div style={{marginTop:15}}><Link className="btn" href={`/apps/${app.id}`}>Voir la fiche</Link></div></article>) : <div className="panel"><h3>Ton catalogue est prêt.</h3><p className="muted">Ajoute ta première fiche depuis le tableau de bord Supabase, dans la table « apps ».</p></div>}</div></section>
 </main>;
}