import {NextResponse} from "next/server";import {headers} from "next/headers";import {stripe} from "@/lib/stripe";import {createClient} from "@supabase/supabase-js";import Stripe from "stripe";
const admin=()=>createClient(process.env.NEXT_PUBLIC_SUPABASE_URL!,process.env.SUPABASE_SERVICE_ROLE_KEY!);
export async function POST(req:Request){const body=await req.text();const signature=(await headers()).get("stripe-signature");if(!signature)return new NextResponse("Missing signature",{status:400});let event:Stripe.Event;
 try{event=stripe.webhooks.constructEvent(body,signature,process.env.STRIPE_WEBHOOK_SECRET!)}catch(e:any){return new NextResponse(`Webhook error: ${e.message}`,{status:400})}
 const sb=admin();
 if(event.type==="checkout.session.completed"){const s=event.data.object as Stripe.Checkout.Session;const uid=s.metadata?.supabase_user_id||s.client_reference_id;if(uid){await sb.from("profiles").upsert({id:uid,stripe_customer_id:String(s.customer||""),stripe_subscription_id:String(s.subscription||""),subscription_status:"active",is_vip:true,updated_at:new Date().toISOString()});}}
 if(["customer.subscription.updated","customer.subscription.deleted"].includes(event.type)){const sub=event.data.object as Stripe.Subscription;const uid=sub.metadata?.supabase_user_id;const active=["active","trialing"].includes(sub.status);if(uid)await sb.from("profiles").upsert({id:uid,stripe_customer_id:String(sub.customer),stripe_subscription_id:sub.id,subscription_status:sub.status,is_vip:active,updated_at:new Date().toISOString()});}
 return NextResponse.json({received:true});
}