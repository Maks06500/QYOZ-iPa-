import {NextResponse} from "next/server";import {supabaseServer} from "@/lib/supabase-server";import {stripe} from "@/lib/stripe";
export async function POST(){const sb=await supabaseServer();const {data:{user}}=await sb.auth.getUser();if(!user)return NextResponse.redirect(new URL("/login",process.env.NEXT_PUBLIC_SITE_URL),303);
 const {data:profile}=await sb.from("profiles").select("stripe_customer_id").eq("id",user.id).maybeSingle();
 const session=await stripe.checkout.sessions.create({mode:"subscription",line_items:[{price:process.env.STRIPE_PRICE_ID!,quantity:1}],success_url:`${process.env.NEXT_PUBLIC_SITE_URL}/account?success=1`,cancel_url:`${process.env.NEXT_PUBLIC_SITE_URL}/vip?cancelled=1`,customer:profile?.stripe_customer_id||undefined,customer_email:profile?.stripe_customer_id?undefined:user.email,client_reference_id:user.id,metadata:{supabase_user_id:user.id},subscription_data:{metadata:{supabase_user_id:user.id}}});
 return NextResponse.redirect(session.url!,303);
}