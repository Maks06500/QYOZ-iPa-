import "./globals.css";
import Link from "next/link";
export const metadata = { title:"QYOZ IPA", description:"Catalogue d'applications et de jeux iOS" };
export default function RootLayout({children}:{children:React.ReactNode}) {
 return <html lang="fr"><body><div className="wrap">
  <header className="nav"><Link className="brand" href="/">QYOZ <b>IPA</b></Link><nav className="links"><Link href="/">Accueil</Link><Link href="/vip">VIP</Link><Link href="/account">Compte</Link></nav></header>
  {children}<footer className="footer">QYOZ IPA · Catalogue indépendant. Respect des droits des développeurs et des licences.</footer>
 </div></body></html>;
}