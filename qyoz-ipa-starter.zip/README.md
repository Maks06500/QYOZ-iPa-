# QYOZ IPA — starter site

A mobile-friendly Next.js starter for an iOS app catalogue, member accounts and a €2.99/month Stripe subscription.

## Included
- Dark black/purple responsive catalogue
- Supabase email/password registration and login
- Member account and VIP status
- Stripe Checkout subscription route
- Stripe webhook that updates VIP status
- Supabase SQL schema with row-level security
- App details and VIP-only content gate

## Important: what is not pre-configured
This is source code, not a hosted/activated website. You must create your own Supabase and Stripe accounts, add the private environment variables, deploy the project, configure the Stripe webhook and test payments. Never send secret keys to anyone or put them in browser code.

## Setup checklist (free tiers where available)

1. Create a Supabase project at https://supabase.com.
2. In Supabase > SQL Editor, run `supabase/schema.sql`.
3. In Supabase > Project Settings > API, copy the Project URL and anon/public key. Copy the service_role key only into server environment variables.
4. Create a Stripe account at https://stripe.com and create a recurring Product/Price for **€2.99 every month**. Copy its `price_...` ID. Start in Stripe test mode.
5. Deploy this folder as a Next.js project on Vercel (https://vercel.com), using GitHub import. Add every variable from `.env.example` in Vercel Project Settings > Environment Variables. Set `NEXT_PUBLIC_SITE_URL` to your deployed URL.
6. In Stripe Developers > Webhooks, add endpoint `https://YOUR-DOMAIN/api/stripe-webhook`. Subscribe to:
   - `checkout.session.completed`
   - `customer.subscription.updated`
   - `customer.subscription.deleted`
   Copy the webhook signing secret into `STRIPE_WEBHOOK_SECRET`.
7. Redeploy after adding environment variables. Test with Stripe test mode before switching to live mode.

## Adding apps
For the first version, manage catalogue entries in Supabase > Table Editor > `apps`.
- `title`, `description`, `category`, `version`
- `published = true` to show the app publicly
- `is_vip = true` to lock its detail/download link to active VIP members
- `download_url` should point only to files you own or are explicitly licensed to redistribute.

Never publish cracked, pirated, paid apps without permission, or files that bypass an app's licensing/signing protections. A VIP fee must not be used to sell access to unauthorized copyrighted files.

## Admin access
Initial catalogue administration is through the Supabase dashboard, which works in a mobile browser. Do not expose the Supabase service_role key. A dedicated in-site admin dashboard is a sensible next step; it should be protected by a server-side allowlist and is intentionally not exposed in this starter.

## Operational notes
- Configure Supabase Auth email settings and redirect URLs for your deployed domain.
- Add your own privacy policy, terms, contact details, cancellation/refund terms and business information before accepting real payments.
- Stripe fees, tax and legal obligations may apply. Free hosting does not mean payment processing is free.
- Before launch, review security policies and test expired/cancelled/failed subscription states.
