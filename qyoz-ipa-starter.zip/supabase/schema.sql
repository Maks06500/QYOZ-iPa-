-- Run this entire file in Supabase > SQL Editor.
create table if not exists public.profiles (
 id uuid primary key references auth.users(id) on delete cascade,
 is_vip boolean not null default false,
 subscription_status text not null default 'free',
 stripe_customer_id text,
 stripe_subscription_id text,
 updated_at timestamptz default now()
);
create table if not exists public.apps (
 id uuid primary key default gen_random_uuid(),
 title text not null,
 description text not null default '',
 category text not null default 'Application',
 version text,
 is_vip boolean not null default false,
 published boolean not null default false,
 download_url text,
 created_at timestamptz not null default now()
);
alter table public.profiles enable row level security;
alter table public.apps enable row level security;
create policy "users read own profile" on public.profiles for select to authenticated using (auth.uid()=id);
create policy "public read published apps" on public.apps for select to anon,authenticated using (published=true);
-- Do not allow users to edit their own VIP status. Only the server webhook uses service_role.
-- Admin content editing should be performed through Supabase dashboard initially.
create or replace function public.handle_new_user() returns trigger language plpgsql security definer set search_path=public as $$
begin insert into public.profiles(id) values(new.id) on conflict(id) do nothing; return new; end; $$;
drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created after insert on auth.users for each row execute procedure public.handle_new_user();
